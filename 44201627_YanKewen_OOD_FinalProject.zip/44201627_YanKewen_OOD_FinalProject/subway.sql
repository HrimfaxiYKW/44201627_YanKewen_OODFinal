/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50622
Source Host           : localhost:3306
Source Database       : subway

Target Server Type    : MYSQL
Target Server Version : 50622
File Encoding         : 65001

Date: 2021-01-06 19:03:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for db_notice_info
-- ----------------------------
DROP TABLE IF EXISTS `db_notice_info`;
CREATE TABLE `db_notice_info` (
  `id` varchar(64) NOT NULL COMMENT '编号',
  `notice` mediumtext COMMENT '内容',
  `time` varchar(128) DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of db_notice_info
-- ----------------------------
INSERT INTO `db_notice_info` VALUES ('331159EFB74D45FCB7EB8198753F1A6A', 'Example1', '2021-01-06 18:15');
INSERT INTO `db_notice_info` VALUES ('3398A4D2AFF7422283F14C3FF6831965', 'A318 Delay', '');
INSERT INTO `db_notice_info` VALUES ('3C3E9C290D4E4A9B8C33AA99A8440322', 'asdqweq', '2021-01-04 17:14');
INSERT INTO `db_notice_info` VALUES ('5A074B538E1046CAA29913BD74452887', 'afwegaerhathah', '2021-01-07 18:41');
INSERT INTO `db_notice_info` VALUES ('776381BD7C104E35A17E90AF5FB15F31', 'qweqwe', '2021-01-03 17:17');
INSERT INTO `db_notice_info` VALUES ('B9B40E4B19924B23ACB073C5FC52C74F', 'A318 Delay', '2021-01-06 15:48');
INSERT INTO `db_notice_info` VALUES ('BE30FF41332240D18825B7C227AB28CE', 'A318 Delay', '2021-01-06 17:14');

-- ----------------------------
-- Table structure for db_train_info
-- ----------------------------
DROP TABLE IF EXISTS `db_train_info`;
CREATE TABLE `db_train_info` (
  `id` varchar(64) NOT NULL COMMENT '编号',
  `trainNumber` varchar(128) DEFAULT NULL COMMENT 'trainNumber',
  `waitingRoom` varchar(128) DEFAULT NULL COMMENT '候车厅',
  `ticketBarrier` varchar(128) DEFAULT NULL COMMENT '检票口',
  `arrivalTime` varchar(128) DEFAULT NULL COMMENT '到站时间',
  `departureTime` varchar(128) DEFAULT NULL COMMENT '离站时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of db_train_info
-- ----------------------------
INSERT INTO `db_train_info` VALUES ('28A36D184FDB44C3BFCF94652A52CBF7', 'wqewqe', 'asd', 'asd', '2021-01-06 15:10', '2021-01-24 15:25');
INSERT INTO `db_train_info` VALUES ('36EBC6AB9A4743ABAD6157B28B0E0D28', 'D1', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('41E34A8664FC403086319590666A0644', '1', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('7CC20EA1EE1649FDB4DD4F8529E3BD83', 'ERWTEJ', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('7FF3355F312145D9B317FA0F0E535FB1', '3', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('85593EE5968E4FEEB12D5696450B4C3D', 'D5189', 'A', 'A10', '2021-01-05 15:24', '2021-01-06 15:24');
INSERT INTO `db_train_info` VALUES ('87B5BC5A984F4E08B792561A00944FDC', '3324', 'YTR', 'RRR', '2021-01-11 18:04', '2021-01-11 18:04');
INSERT INTO `db_train_info` VALUES ('906BA5717F0D462FA5BC22035700CCEF', 'Q', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('9841803F135640E0996AABDF3B0D48FB', 'YREWT', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('C36391E3B3C64A8DA6259AD422502CB7', '2', '', '', '', '');
INSERT INTO `db_train_info` VALUES ('DA28C46D251D48A78B893DAE0C468576', 'EWRT', '', '', '', '');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` varchar(64) NOT NULL COMMENT '编号',
  `username` varchar(128) NOT NULL COMMENT '账号',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `role` varchar(128) NOT NULL COMMENT '角色',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', 'sys', '1', '1');
INSERT INTO `sys_user` VALUES ('2', 'subway', '1', '2');
