package com.so.demosboot.modules.db.entity;


import com.so.demosboot.common.baseData.BaseEntity;
import org.hibernate.validator.constraints.Length;

public class TrainInfo extends BaseEntity<TrainInfo> {

    private static final long serialVersionUID = 1L;
    private String id;
    private String trainNumber;
    private String waitingRoom;
    private String ticketBarrier;
    private String arrivalTime;
    private String boardingTime;
    private String departureTime;



    public TrainInfo() {
        super();
    }

    public TrainInfo(String id){
        this.id = id;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public String getTrainNumber() {
        return trainNumber;
    }
    @Length(min=1, max=128, message="Length must between 1-128")
    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }

    public String getWaitingRoom() {
        return waitingRoom;
    }
    @Length(min=1, max=128, message="Length must between 1-128")
    public void setWaitingRoom(String waitingRoom) {
        this.waitingRoom = waitingRoom;
    }

    public String getTicketBarrier() {
        return ticketBarrier;
    }
    @Length(min=1, max=128, message="Length must between 1-128")
    public void setTicketBarrier(String ticketBarrier) {
        this.ticketBarrier = ticketBarrier;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }
    @Length(min=1, max=128, message="Length must between 1-128")
    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getBoardingTime() {
        return boardingTime;
    }
    @Length(min=1, max=128, message="Length must between 1-128")
    public void setBoardingTime(String boardingTime) {
        this.boardingTime = boardingTime;
    }

    public String getDepartureTime() {
        return departureTime;
    }
    @Length(min=1, max=128, message="Length must between 1-128")
    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }


    @Override
    public String toString() {
        return "TrainInfo{" +
                "id='" + id + '\'' +
                ", trainNumber='" + trainNumber + '\'' +
                ", waitingRoom='" + waitingRoom + '\'' +
                ", ticketBarrier='" + ticketBarrier + '\'' +
                ", arrivalTime='" + arrivalTime + '\'' +
                ", boardingTime='" + boardingTime + '\'' +
                ", departureTime='" + departureTime + '\'' +
                ", id='" + id + '\'' +
                ", remarks='" + remarks + '\'' +
                ", pageNo=" + pageNo +
                ", pageSize=" + pageSize +
                ", sqlStr='" + sqlStr + '\'' +
                '}';
    }
}
