package com.so.demosboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSbootApplication.class, args);
	}

}
