package com.so.demosboot.modules.db.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

import com.so.demosboot.common.utils.StringUtils;
import com.so.demosboot.modules.db.entity.TrainInfo;
import com.so.demosboot.modules.db.service.TrainInfoService;

import java.lang.System;
@Controller
@RequestMapping(value = "/db/trainInfo")
public class TrainInfoController{
    TrainInfoController(){
        System.out.println("TrainInfoController");
    }
    @Autowired
    private TrainInfoService trainInfoService;
    @ModelAttribute
    public TrainInfo get(@RequestParam(required=false) String id) {
        TrainInfo entity = null;
        if (StringUtils.isNotBlank(id)){
            entity = trainInfoService.getById(id);
        }else{
            entity = new TrainInfo();
        }
        //System.out.println(entity);
        return entity;
    }

    @RequestMapping(value = {"list", ""})
    public String list(TrainInfo trainInfo, Model model) {
        System.out.println("TrainInfoList");
        PageHelper.startPage(trainInfo.getPageNo(),10);
        List<TrainInfo> list = trainInfoService.findList(trainInfo);
        PageInfo<TrainInfo> pageInfo = new PageInfo<TrainInfo>(list, 10);
        model.addAttribute("pageInfo",pageInfo);
        return "db/trainInfoList";
    }


    @RequestMapping(value = "form")
    public String form(TrainInfo trainInfo, Model model) {

        if (StringUtils.isNotEmpty(trainInfo.getId())){
            trainInfo = trainInfoService.getById(trainInfo.getId());
            model.addAttribute("trainInfo",trainInfo);
        }
        return "db/trainInfoForm";
    }



    @RequestMapping(value = "save")
    public String save(TrainInfo trainInfo,RedirectAttributes redirectAttributes) {
        trainInfoService.save(trainInfo);
       redirectAttributes.addFlashAttribute("msg", "save success！");
        return "redirect:"+"/db/trainInfo";
    }

    @RequestMapping(value = "delete")
    public String delete(TrainInfo trainInfo, RedirectAttributes redirectAttributes) {
        trainInfoService.delete(trainInfo.getId());
        redirectAttributes.addFlashAttribute("msg", "delete success！");
        return "redirect:"+"/db/trainInfo";
    }

    @ResponseBody
    @RequestMapping(value = "trainInfo")
    public TrainInfo trainInfo(TrainInfo trainInfo, Model model) {
        trainInfo = trainInfoService.getById(trainInfo.getId());
        return trainInfo;
    }

}