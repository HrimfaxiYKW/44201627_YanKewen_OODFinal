package com.so.demosboot.modules.db.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

import com.so.demosboot.common.utils.StringUtils;
import com.so.demosboot.modules.db.entity.TrainNoticeInfo;
import com.so.demosboot.modules.db.service.TrainNoticeInfoService;

import java.lang.System;
@Controller
@RequestMapping(value = "/db/trainNoticeInfo")
public class TrainNoticeInfoController{
    TrainNoticeInfoController(){
        System.out.println("TrainNoticeInfoController");
    }
    @Autowired
    private TrainNoticeInfoService trainNoticeInfoService;
    @ModelAttribute
    public TrainNoticeInfo get(@RequestParam(required=false) String id) {
        TrainNoticeInfo entity = null;
        if (StringUtils.isNotBlank(id)){
            entity = trainNoticeInfoService.getById(id);
        }else{
            entity = new TrainNoticeInfo();
        }
        //System.out.println(entity);
        return entity;
    }

    @RequestMapping(value = {"list", ""})
    public String list(TrainNoticeInfo trainNoticeInfo, Model model) {
        System.out.println("TrainNoticeInfoList");
        PageHelper.startPage(trainNoticeInfo.getPageNo(),10);
        List<TrainNoticeInfo> list = trainNoticeInfoService.findList(trainNoticeInfo);
        System.out.println("motherfuck1");
        PageInfo<TrainNoticeInfo> pageInfo = new PageInfo<TrainNoticeInfo>(list, 10);
        model.addAttribute("pageInfo",pageInfo);
        System.out.println("motherfuck2");
        return "db/trainNoticeInfoList";
    }


    @RequestMapping(value = "form")
    public String form(TrainNoticeInfo trainNoticeInfo, Model model) {

        if (StringUtils.isNotEmpty(trainNoticeInfo.getId())){
            trainNoticeInfo = trainNoticeInfoService.getById(trainNoticeInfo.getId());
            model.addAttribute("trainNoticeInfo",trainNoticeInfo);
        }
        return "db/trainNoticeInfoForm";
    }



    @RequestMapping(value = "save")
    public String save(TrainNoticeInfo trainNoticeInfo,RedirectAttributes redirectAttributes) {
        trainNoticeInfoService.save(trainNoticeInfo);
        redirectAttributes.addFlashAttribute("msg", "save success！");
        return "redirect:"+"/db/trainNoticeInfo";
    }

    @RequestMapping(value = "delete")
    public String delete(TrainNoticeInfo trainNoticeInfo, RedirectAttributes redirectAttributes) {
        trainNoticeInfoService.delete(trainNoticeInfo.getId());
        redirectAttributes.addFlashAttribute("msg", "delete success！");
        return "redirect:"+"/db/trainNoticeInfo";
    }

    @ResponseBody
    @RequestMapping(value = "trainNoticeInfo")
    public TrainNoticeInfo trainNoticeInfo(TrainNoticeInfo trainNoticeInfo, Model model) {
        trainNoticeInfo = trainNoticeInfoService.getById(trainNoticeInfo.getId());
        return trainNoticeInfo;
    }

}