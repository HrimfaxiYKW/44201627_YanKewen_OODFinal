package com.so.demosboot.modules.db.service;

import com.so.demosboot.common.baseData.BaseService;
import com.so.demosboot.modules.db.dao.TrainNoticeInfoDao;
import com.so.demosboot.modules.db.entity.TrainNoticeInfo;
import org.springframework.stereotype.Service;

@Service
public class TrainNoticeInfoService extends BaseService<TrainNoticeInfoDao, TrainNoticeInfo> {
}