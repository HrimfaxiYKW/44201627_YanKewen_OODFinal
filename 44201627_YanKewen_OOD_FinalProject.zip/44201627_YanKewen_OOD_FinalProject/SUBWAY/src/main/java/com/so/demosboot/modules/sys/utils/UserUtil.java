package com.so.demosboot.modules.sys.utils;

import com.so.demosboot.modules.sys.entity.User;
import javax.servlet.http.HttpServletRequest;
public class UserUtil {
	/**
	 * 获取当前登录的用户
	 */
	public static User currentUser(HttpServletRequest request){
		User user = null;
		Object attribute = request.getSession().getAttribute("login");
		if (attribute!=null && attribute  instanceof User) {
			user = (User) attribute;
			return user;
		}
		return user;
	}
	
	
}
