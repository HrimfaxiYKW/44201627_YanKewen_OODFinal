package com.so.demosboot.modules.sys.dao;

import com.so.demosboot.common.baseData.BaseDao;
import com.so.demosboot.modules.sys.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserDao extends BaseDao<User> {

    public User login(User user);

}
