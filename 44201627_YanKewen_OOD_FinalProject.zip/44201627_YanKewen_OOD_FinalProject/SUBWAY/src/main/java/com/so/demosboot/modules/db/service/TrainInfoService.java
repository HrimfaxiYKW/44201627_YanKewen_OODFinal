package com.so.demosboot.modules.db.service;

import com.so.demosboot.common.baseData.BaseService;
import com.so.demosboot.modules.db.dao.TrainInfoDao;
import com.so.demosboot.modules.db.entity.TrainInfo;
import org.springframework.stereotype.Service;

@Service
public class TrainInfoService extends BaseService<TrainInfoDao, TrainInfo> {
}