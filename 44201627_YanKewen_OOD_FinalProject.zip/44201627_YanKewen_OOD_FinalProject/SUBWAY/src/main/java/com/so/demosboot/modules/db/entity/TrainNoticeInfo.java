package com.so.demosboot.modules.db.entity;
import com.so.demosboot.common.baseData.BaseEntity;
import org.hibernate.validator.constraints.Length;
public class TrainNoticeInfo extends BaseEntity<TrainNoticeInfo>{
    private static final long serialVersionUID = 1L;
    private String id;
    private String notice;
    private String time;

    public TrainNoticeInfo() {
        super();
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public String getNotice() {
        return notice;
    }
    @Length(min=1, max=25535, message="Length must between 1-25535")
    public void setNotice(String notice) {
        this.notice = notice;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

}
