package com.so.demosboot.modules.sys.controller;

import com.so.demosboot.modules.sys.entity.User;
import com.so.demosboot.modules.sys.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

@Controller
@RequestMapping("/sys/user")
public class UserController {

    @Autowired
    UserService userService;
    @RequestMapping("/login")
    public String login(User user, HttpServletRequest request, Model model) {
        User login = userService.login(user);
        if (login != null) {
            request.getSession().setAttribute("login", login);

            System.err.println(request.getSession().getId()
                    + "\n" + request.getSession().getCreationTime()
                    + "\n" + request.getSession().getLastAccessedTime());

            Enumeration<?> enumeration = request.getSession().getAttributeNames();
            while (enumeration.hasMoreElements()) {

                String name = enumeration.nextElement().toString();
                // 根据键值取session中的值
                Object value = request.getSession().getAttribute(name);
                System.err.println(name + ":" + value);

            }
            System.err.println(request.getSession().isNew());
            return "redirect:" + "/index";
            //return "redirect:" + "/db/checkWorkInfo";
        } else {
            model.addAttribute("msg", "username or password error！");
            model.addAttribute("username", user.getUsername());
            model.addAttribute("password", user.getPassword());
            return "sys/login";
        }
    }


    @RequestMapping("/logout")
    public String logout(HttpServletRequest request) {
        request.getSession().invalidate();
        return "redirect:" + "/login";
    }
}
