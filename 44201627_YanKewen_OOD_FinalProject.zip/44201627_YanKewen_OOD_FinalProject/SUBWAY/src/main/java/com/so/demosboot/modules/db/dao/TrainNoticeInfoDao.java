package com.so.demosboot.modules.db.dao;

import com.so.demosboot.common.baseData.BaseDao;
import com.so.demosboot.modules.db.entity.TrainNoticeInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TrainNoticeInfoDao extends BaseDao<TrainNoticeInfo> {

}