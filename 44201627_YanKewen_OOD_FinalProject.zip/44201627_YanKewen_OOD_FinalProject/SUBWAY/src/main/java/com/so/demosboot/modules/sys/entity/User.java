package com.so.demosboot.modules.sys.entity;

import com.so.demosboot.common.baseData.BaseEntity;

public class User extends BaseEntity<User> {

	private String username;		// 用户名
	private String password;		// 密码
	private String role;		// 角色

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		return "User{" +
				"username='" + username + '\'' +
				", password='" + password + '\'' +
				", role='" + role + '\'' +
				'}';
	}
}
